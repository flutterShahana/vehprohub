<?php 

    include'connect.php';
	$work_id = $_POST['work_id'];
	$amt = $_POST['amt'];
	$avgTime = $_POST['avgTime'];
	
	$sql = $conn->query("UPDATE workshop_tb set amount='$amt',avgTime='$avgTime' where work_id='$work_id'");
if($sql){
	
		$myarray['result']="success";
       
	}


else 

{
	$myarray['result']="failed";

	

}
	echo json_encode($myarray);
    ?>