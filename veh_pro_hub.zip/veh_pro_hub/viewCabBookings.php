

<?php
include 'connect.php';
$pro_id=$_POST['pro_id'];
$req_status=$_POST['req_status'];
// SELECT * FROM `booking_tb` INNER JOIN `cabs_tb` ON `booking_tb`.`cab_id` = `cabs_tb`.`cab_id`  INNER JOIN `register_tb` ON `booking_tb`.`user_id` = `register_tb`.`log_id` WHERE `booking_tb`.`user_id` = '6' AND `booking_tb`.`status` = 'requested';

$data=mysqli_query($conn,"SELECT * FROM `booking_tb` INNER JOIN `cabs_tb` ON `booking_tb`.`cab_id` = `cabs_tb`.`cab_id` INNER JOIN `register_tb` ON `booking_tb`.`user_id` = `register_tb`.`log_id` WHERE cabs_tb.pro_id='$pro_id' AND `booking_tb`.`status` = '$req_status';");

$list=array();

if($data->num_rows>0){
    while($row=mysqli_fetch_assoc($data)){
       // $list[]=$row;

       $myarray['book_id']=$row['book_id'];
       $myarray['source']=$row['source'];
       $myarray['dest']=$row['dest'];
       $myarray['bookingDate']=$row['bookingDate'];
       $myarray['bookingTime']=$row['bookingTime'];
       $myarray['date']=$row['date'];
       $myarray['rate']=$row['rate'];
       $myarray['name']=$row['name'];
       $myarray['size']=$row['size'];
       $myarray['type']=$row['type'];
       $myarray['cab_id']=$row['cab_id'];
       $myarray['image']=$row['image'];
       $myarray['username']=$row['username'];
       $myarray['phone']=$row['phone'];
       $myarray['pay_status']=$row['pay_status'];
       $myarray['tot_hr']=$row['tot_hr'];
    //    $myarray['person']=$row['person'];

       $myarray['result']="success";
       array_push($list,$myarray);
    }   

} 
else{
    $myarray['result']="failed";
    array_push($list,$myarray);
   // $list='Failed';
 
}
echo json_encode($list);
?>
