<?php
include 'connect.php';
$booikingId=$_POST['booikingId'];
$sql1= mysqli_query($conn,"UPDATE workshop_booking_tb set service_completion='finished'where work_book_id='$booikingId'");
if($sql1){
    $myarray['result']="success";
    $myarray['response']="done";
} else{
    $myarray['result']="failed";
   
}
echo json_encode($myarray);
?>