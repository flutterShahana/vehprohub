
<?php
include 'connect.php';
$pro_id=$_POST['pro_id'];
$type=$_POST['type'];


$data=mysqli_query($conn,"SELECT * FROM rentals_tb inner JOIN register_tb on rentals_tb.pro_id=register_tb.log_id WHERE rentals_tb.pro_id='$pro_id'  && rentals_tb.availability=1 && rentals_tb.type='$type'");

$list=array();

if($data->num_rows>0){
    while($row=mysqli_fetch_assoc($data)){
       // $list[]=$row;

       $myarray['description']=$row['des'];
       $myarray['image']=$row['image'];
       $myarray['type']=$row['type'];
       $myarray['name']=$row['name'];
       $myarray['rent']=$row['rent'];
       $myarray['fuel']=$row['fuel'];
       $myarray['phone']=$row['phone'];
       $myarray['availability']=$row['availability'];
       $myarray['log_id']=$row['log_id'];
       $myarray['rent_id']=$row['rent_id'];
       $myarray['result']="success";
       array_push($list,$myarray);
    }   

} 
else{
    $myarray['result']="failed";
    array_push($list,$myarray);
   // $list='Failed';
 
}
echo json_encode($list);
?>
