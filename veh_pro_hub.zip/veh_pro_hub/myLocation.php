<?php
include 'connect.php';
  $login_id=$_POST['login_id'];
 $sql= mysqli_query($conn,"SELECT * from login_tb inner join register_tb on login_tb.log_id=register_tb.log_id where login_tb.log_id='$login_id'");
  if($sql->num_rows>0){
    while($row=mysqli_fetch_assoc($sql)){
        $myarray['result']='success';
         $myarray['login_id']=$row['log_id'];
         $myarray['lati']=$row['lati'];
         $myarray['longi']=$row['longi'];
         $myarray['location']=$row['location'];
         $myarray['place']=$row['place'];
    }
  }
  else{
    $myarray['message']='Failed';
  }
echo json_encode($myarray);
?>