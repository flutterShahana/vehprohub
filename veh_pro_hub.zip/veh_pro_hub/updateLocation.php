<?php
include 'connect.php';
//$office_id=$_POST['officeId'];
$pro_id=$_POST['pro_id'];
$lati=$_POST['lati'];
$longi=$_POST['longi'];
$loc=$_POST['location'];
$place=$_POST['place'];
$sql1= mysqli_query($conn,"UPDATE register_tb set lati='$lati',longi='$longi',place='$place', location='$loc' where log_id ='$pro_id'
");
if($sql1){
    $myarray['result']="success";
    $myarray['response']="done";
} else{
    $myarray['result']="failed";
   
}
echo json_encode($myarray);
?>