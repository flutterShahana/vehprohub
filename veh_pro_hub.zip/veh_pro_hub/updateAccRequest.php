<?php
include 'connect.php';
//$office_id=$_POST['officeId'];
$booikingId=$_POST['booikingId'];
$reply=$_POST['reply'];
$sql1= mysqli_query($conn,"UPDATE acc_booking_tb set status='$reply'where acc_book_id='$booikingId'");
if($sql1){
    $myarray['result']="success";
    $myarray['response']="done";
} else{
    $myarray['result']="failed";
   
}
echo json_encode($myarray);
?>