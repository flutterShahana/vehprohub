<?php 

    include'connect.php';
	$cab_id = $_POST['cab_id'];
	
	$sql = $conn->query("DELETE from cabs_tb where cab_id='$cab_id'");
if($sql){
	
		$myarray['result']="success";
       
	}


else 

{
	$myarray['result']="failed";

	

}
	echo json_encode($myarray);
    ?>