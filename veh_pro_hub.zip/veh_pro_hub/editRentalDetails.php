<?php 

    include'connect.php';
	$rent_id = $_POST['rent_id'];
	$rent = $_POST['rent'];
	
	$sql = $conn->query("UPDATE rentals_tb set rent='$rent'where rent_id='$rent_id'");
if($sql){
	
		$myarray['result']="success";
       
	}


else 

{
	$myarray['result']="failed";

	

}
	echo json_encode($myarray);
    ?>