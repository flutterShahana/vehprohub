
<?php
include '../connect.php';
$type=$_POST['vehType'];


$data=mysqli_query($conn,"SELECT * FROM accessories_tb inner JOIN register_tb on accessories_tb.pro_id=register_tb.log_id WHERE accessories_tb.quantity>0 && accessories_tb.type='$type'
");

$list=array();

if($data->num_rows>0){
    while($row=mysqli_fetch_assoc($data)){
       // $list[]=$row;

       $myarray['acc_id']=$row['acc_id'];
       $myarray['description']=$row['des'];
       $myarray['image']=$row['image'];
       $myarray['type']=$row['type'];
       $myarray['name']=$row['name'];
       $myarray['rate']=$row['rate'];
       $myarray['brand']=$row['brand'];
       $myarray['phone']=$row['phone'];
       $myarray['quantity']=$row['quantity'];
       $myarray['log_id']=$row['log_id'];
       $myarray['result']="success";
       array_push($list,$myarray);
    }   

} 
else{
    $myarray['result']="failed";
    array_push($list,$myarray);
   // $list='Failed';
 
}
echo json_encode($list);
?>
