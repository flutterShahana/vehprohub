<?php
include '../connect.php';

$sql1=mysqli_query($conn,"SELECT * FROM offer_tb INNER JOIN register_tb on offer_tb.pro_id=register_tb.log_id");
$list=array();

if($sql1->num_rows>0){
    while($row=mysqli_fetch_assoc($sql1)){
    $myarray['result']="success";

    $myarray['offer']=$row['offer'];
    $myarray['start_date']=$row['start_date'];
    $myarray['end_date']=$row['end_date'];
    $myarray['username']=$row['username'];
    $myarray['phone']=$row['phone'];
    $myarray['place']=$row['place'];
    array_push($list,$myarray);

    }
} else{
    $myarray['result']="failed";
    array_push($list,$myarray);

   
}
echo json_encode($list);
?>