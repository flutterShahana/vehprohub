<?php
include '../connect.php';
$cab_id=$_POST['cab_id'];
$user_id=$_POST['user_id'];
$source=$_POST['source'];
$dest=$_POST['dest'];
$bookingDate=$_POST['bookingDate'];
$bookingTime=$_POST['bookingTime'];
$date=$_POST['date'];





$sql1=mysqli_query($conn,"INSERT INTO booking_tb(cab_id,user_id,source,dest,bookingDate,bookingTime,date)
values('$cab_id','$user_id','$source','$dest','$bookingDate','$bookingTime','$date')");
if($sql1){
    $myarray['result']="success";
    $myarray['response']="done";
} else{
    $myarray['result']="failed";
   
}
echo json_encode($myarray);
?>