<?php
include '../connect.php';
$acc_id=$_POST['acc_id'];
$user_id=$_POST['user_id'];
$qnty=$_POST['qnty'];
$updated_qnty=$_POST['updated_qnty'];
$date=$_POST['date'];
$amtToPay=$_POST['amtToPay'];




$sql1=mysqli_query($conn,"INSERT INTO acc_booking_tb(acc_id,user_id,quantity,date,tot)
values('$acc_id','$user_id','$qnty','$date','$amtToPay')");
$sql2=mysqli_query($conn,"UPDATE accessories_tb set quantity='$updated_qnty' where acc_id='$acc_id' ");
$sql3=mysqli_query($conn,"SELECT quantity from accessories_tb where acc_id='$acc_id' ");
if($sql1 && $sql2){
    if($sql3->num_rows>0){
        while($row=mysqli_fetch_assoc($sql3)){
            $myarray['quantity']=$row['quantity'];
        }
    }
    $myarray['result']="success";
    $myarray['response']="done";
    

} else{
    $myarray['result']="failed";
   
}
echo json_encode($myarray);
?>