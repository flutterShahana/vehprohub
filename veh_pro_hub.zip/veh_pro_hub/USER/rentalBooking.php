<?php
include '../connect.php';
$rental_id=$_POST['rental_id'];
$user_id=$_POST['user_id'];
$days=$_POST['days'];
$pickDate=$_POST['pickDate'];
$pickTime=$_POST['pickTime'];
$date=$_POST['date'];
$pay=$_POST['pay'];
$sql1=mysqli_query($conn,"INSERT INTO rental_booking_tb(rental_id,user_id,days,pick_up_date,pick_up_time,date,pay)
values('$rental_id','$user_id','$days','$pickDate','$pickTime','$date','$pay')");
if($sql1){
    $myarray['result']="success";
    $myarray['response']="done";
} else{
    $myarray['result']="failed";
   
}
echo json_encode($myarray);
?>