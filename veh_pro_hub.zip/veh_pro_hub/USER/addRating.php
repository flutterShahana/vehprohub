<?php
include '../connect.php';
$user_id=$_POST['user_id'];
$star=$_POST['star'];
$feedback=$_POST['feedback'];
$date=$_POST['date'];
$service=$_POST['service'];





$sql1=mysqli_query($conn,"INSERT INTO feedback_tb(user_id,star,feedback,date,service)
values('$user_id','$star','$feedback','$date','$service')");
if($sql1){
    $myarray['result']="success";
    $myarray['response']="done";
} else{
    $myarray['result']="failed";
   
}
echo json_encode($myarray);
?>     