
<?php
include '../connect.php';
$type=$_POST['vehType'];


$data=mysqli_query($conn,"SELECT * FROM cabs_tb inner JOIN register_tb on cabs_tb.pro_id=register_tb.log_id WHERE cabs_tb.availability=1 && cabs_tb.type='$type'");

$list=array();

if($data->num_rows>0){
    while($row=mysqli_fetch_assoc($data)){
       // $list[]=$row;

       $myarray['description']=$row['des'];
       $myarray['image']=$row['image'];
       $myarray['type']=$row['type'];
       $myarray['name']=$row['name'];
       $myarray['rate']=$row['rate'];
       $myarray['size']=$row['size'];
       $myarray['person']=$row['person'];
       $myarray['phone']=$row['phone'];
       $myarray['availability']=$row['availability'];
       $myarray['log_id']=$row['log_id'];
       $myarray['cab_id']=$row['cab_id'];
       $myarray['result']="success";
       array_push($list,$myarray);
    }   

} 
else{
    $myarray['result']="failed";
    array_push($list,$myarray);
   // $list='Failed';
 
}
echo json_encode($list);
?>
