<?php
include '../../connect.php';
$pay_type=$_POST['pay_type'];
$pay_method=$_POST['pay_method'];
$pay_status=$_POST['pay_status'];
$booking_id=$_POST['booking_id'];



$sql1=mysqli_query($conn,"UPDATE  acc_booking_tb set pay_type='$pay_type',pay_method='$pay_method' ,pay_status='$pay_status'  where acc_book_id='$booking_id'");
if($sql1){
    $myarray['result']="success";
    $myarray['response']="done";
} else{
    $myarray['result']="failed";
   
}
echo json_encode($myarray);
?>