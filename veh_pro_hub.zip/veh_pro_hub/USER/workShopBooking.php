<?php
include '../connect.php';
$work_id=$_POST['work_id'];
$user_id=$_POST['user_id'];
$bookingDate=$_POST['bookingDate'];
$bookingTime=$_POST['bookingTime'];
$date=$_POST['date'];





$sql1=mysqli_query($conn,"INSERT INTO workshop_booking_tb(work_id,user_id,booking_date,booking_time,date)
values('$work_id','$user_id','$bookingDate','$bookingTime','$date')");
if($sql1){
    $myarray['result']="success";
    $myarray['response']="done";
} else{
    $myarray['result']="failed";
   
}
echo json_encode($myarray);
?>