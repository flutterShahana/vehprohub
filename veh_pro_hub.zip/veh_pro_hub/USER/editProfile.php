<!-- <?php
include 'connect.php';
$uname=$_POST['uname'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$pass=$_POST['pass'];
$place=$_POST['place'];
$user_id=$_POST['user_id']
$sql1= mysqli_query($conn,"UPDATE login_tb set email='$email',password='$pass' where log_id='$user_id'");

$sql2=mysqli_query($conn,"UPDATE  register_tb set username='$uname',phone='$phone',place='$place' where log_id='$user_id'");
if($sql1 && $sql2){
    $myarray['result']="success";
    $myarray['response']="done";
} else{
    $myarray['result']="failed";
   
}
echo json_encode($myarray);
?> -->