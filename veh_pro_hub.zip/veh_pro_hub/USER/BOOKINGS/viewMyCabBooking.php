


<?php
include '../../connect.php';
$user_id=$_POST['user_id'];
$req_status=$_POST['req_status'];

//SELECT * FROM `booking_tb`INNER JOIN cabs_tb ON booking_tb.cab_id=cabs_tb.cab_id INNER JOIN register_tb on booking_tb.user_id=register_tb.log_id where user_id=1 && booking_tb.status='accepted' AND `booking_tb`.`bookingDate` > CURDATE() ORDER BY `booking_tb`.`bookingDate` ASC; -->

// $data=mysqli_query($conn,"SELECT * FROM `booking_tb`INNER JOIN cabs_tb ON booking_tb.cab_id=cabs_tb.cab_id INNER JOIN register_tb on booking_tb.user_id=register_tb.log_id where user_id='$user_id' && booking_tb.status='accepted';");
// $data=mysqli_query($conn,"SELECT *
// FROM `booking_tb`
// INNER JOIN `cabs_tb` ON `booking_tb`.`cab_id` = `cabs_tb`.`cab_id`
// INNER JOIN (
//     SELECT `register_tb`.`phone`, `cabs_tb`.`cab_id`
//     FROM `cabs_tb`
//     INNER JOIN `register_tb` ON `cabs_tb`.`pro_id` = `register_tb`.`log_id`
// ) AS `subquery` ON `cabs_tb`.`cab_id` = `subquery`.`cab_id`
// INNER JOIN `register_tb` ON `booking_tb`.`user_id` = `register_tb`.`log_id`
// WHERE `booking_tb`.`user_id` = '$user_id'
//   AND `booking_tb`.`status` = 'requested';");
$data=mysqli_query($conn,"SELECT * FROM `booking_tb` INNER JOIN `cabs_tb` ON `booking_tb`.`cab_id` = `cabs_tb`.`cab_id` INNER JOIN ( SELECT `register_tb`.`phone` as pro_phone, `cabs_tb`.`cab_id` FROM `cabs_tb` INNER JOIN `register_tb` ON `cabs_tb`.`pro_id` = `register_tb`.`log_id` ) AS `subquery` ON `cabs_tb`.`cab_id` = `subquery`.`cab_id` INNER JOIN `register_tb` ON `booking_tb`.`user_id` = `register_tb`.`log_id` WHERE `booking_tb`.`user_id` = '$user_id' AND `booking_tb`.`status` = '$req_status';");

$list=array();

if($data->num_rows>0){
    while($row=mysqli_fetch_assoc($data)){
       // $list[]=$row;

       $myarray['book_id']=$row['book_id'];
       $myarray['pro_phone']=$row['pro_phone'];
       $myarray['source']=$row['source'];
       $myarray['dest']=$row['dest'];
       $myarray['bookingDate']=$row['bookingDate'];
       $myarray['bookingTime']=$row['bookingTime'];
       $myarray['rate']=$row['rate'];
       $myarray['name']=$row['name'];
       $myarray['size']=$row['size'];
       $myarray['type']=$row['type'];
       $myarray['cab_id']=$row['cab_id'];
       $myarray['image']=$row['image'];
       $myarray['username']=$row['username'];
       $myarray['phone']=$row['phone'];

       $myarray['result']="success";
       array_push($list,$myarray);
    }   

} 
else{
    $myarray['result']="failed";
    array_push($list,$myarray);
   // $list='Failed';
 
}
echo json_encode($list);
?>
