


<?php
include '../../connect.php';
$user_id=$_POST['user_id'];
$req_status=$_POST['req_status'];

//SELECT * FROM `booking_tb`INNER JOIN cabs_tb ON booking_tb.cab_id=cabs_tb.cab_id INNER JOIN register_tb on booking_tb.user_id=register_tb.log_id where user_id=1 && booking_tb.status='accepted' AND `booking_tb`.`bookingDate` > CURDATE() ORDER BY `booking_tb`.`bookingDate` ASC; -->

// $data=mysqli_query($conn,"SELECT * FROM `booking_tb`INNER JOIN cabs_tb ON booking_tb.cab_id=cabs_tb.cab_id INNER JOIN register_tb on booking_tb.user_id=register_tb.log_id where user_id='$user_id' && booking_tb.status='accepted';");
// $data=mysqli_query($conn,"SELECT *
// FROM `booking_tb`
// INNER JOIN `cabs_tb` ON `booking_tb`.`cab_id` = `cabs_tb`.`cab_id`
// INNER JOIN (
//     SELECT `register_tb`.`phone`, `cabs_tb`.`cab_id`
//     FROM `cabs_tb`
//     INNER JOIN `register_tb` ON `cabs_tb`.`pro_id` = `register_tb`.`log_id`
// ) AS `subquery` ON `cabs_tb`.`cab_id` = `subquery`.`cab_id`
// INNER JOIN `register_tb` ON `booking_tb`.`user_id` = `register_tb`.`log_id`
// WHERE `booking_tb`.`user_id` = '$user_id'
//   AND `booking_tb`.`status` = 'requested';");
$data=mysqli_query($conn,"SELECT acc_booking_tb.*,accessories_tb.*,register_tb.*, acc_booking_tb.quantity as booking_qnty ,`register_tb`.`phone` as pro_phone,accessories_tb.quantity as acc_qnty FROM `acc_booking_tb` INNER JOIN accessories_tb ON `acc_booking_tb`.`acc_id` = `accessories_tb`.`acc_id` INNER JOIN ( SELECT  * FROM `accessories_tb` INNER JOIN `register_tb` ON `accessories_tb`.`pro_id` = `register_tb`.`log_id` ) AS `subquery` ON `accessories_tb`.`acc_id` = `subquery`.`acc_id` INNER JOIN `register_tb` ON `acc_booking_tb`.`user_id` = `register_tb`.`log_id` WHERE `acc_booking_tb`.`user_id` = '$user_id' AND `acc_booking_tb`.`status` = '$req_status';");

$list=array();

if($data->num_rows>0){
    while($row=mysqli_fetch_assoc($data)){
       // $list[]=$row;

       $myarray['acc_book_id']=$row['acc_book_id'];
       $myarray['acc_id']=$row['acc_id'];
       $myarray['pro_phone']=$row['pro_phone'];
       $myarray['quantity']=$row['booking_qnty'];
       $myarray['tot']=$row['tot'];
       $myarray['rate']=$row['rate'];
       $myarray['name']=$row['name'];
       $myarray['brand']=$row['brand'];
       $myarray['type']=$row['type'];
       $myarray['image']=$row['image'];
       $myarray['username']=$row['username'];
       $myarray['result']="success";
       $myarray['phone']=$row['phone'];
       $myarray['pay_status']=$row['pay_status'];

       array_push($list,$myarray);
    }   

} 
else{
    $myarray['result']="failed";
    array_push($list,$myarray);
   // $list='Failed';
 
}
echo json_encode($list);
?>
