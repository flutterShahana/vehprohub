


<?php
include '../../connect.php';
$user_id=$_POST['user_id'];
$req_status=$_POST['req_status'];

//SELECT * FROM `booking_tb`INNER JOIN cabs_tb ON booking_tb.cab_id=cabs_tb.cab_id INNER JOIN register_tb on booking_tb.user_id=register_tb.log_id where user_id=1 && booking_tb.status='accepted' AND `booking_tb`.`bookingDate` > CURDATE() ORDER BY `booking_tb`.`bookingDate` ASC; -->

// $data=mysqli_query($conn,"SELECT * FROM `booking_tb`INNER JOIN cabs_tb ON booking_tb.cab_id=cabs_tb.cab_id INNER JOIN register_tb on booking_tb.user_id=register_tb.log_id where user_id='$user_id' && booking_tb.status='accepted';");
// $data=mysqli_query($conn,"SELECT *
// FROM `booking_tb`
// INNER JOIN `cabs_tb` ON `booking_tb`.`cab_id` = `cabs_tb`.`cab_id`
// INNER JOIN (
//     SELECT `register_tb`.`phone`, `cabs_tb`.`cab_id`
//     FROM `cabs_tb`
//     INNER JOIN `register_tb` ON `cabs_tb`.`pro_id` = `register_tb`.`log_id`
// ) AS `subquery` ON `cabs_tb`.`cab_id` = `subquery`.`cab_id`
// INNER JOIN `register_tb` ON `booking_tb`.`user_id` = `register_tb`.`log_id`
// WHERE `booking_tb`.`user_id` = '$user_id'
//   AND `booking_tb`.`status` = 'requested';");
$data=mysqli_query($conn,"SELECT * FROM `rental_booking_tb` INNER JOIN rentals_tb ON `rental_booking_tb`.`rental_id` = `rentals_tb`.`rent_id` INNER JOIN ( SELECT `register_tb`.`phone` as pro_phone, `rentals_tb`.`rent_id` FROM `rentals_tb` INNER JOIN `register_tb` ON `rentals_tb`.`pro_id` = `register_tb`.`log_id` ) AS `subquery` ON `rentals_tb`.`rent_id` = `subquery`.`rent_id` INNER JOIN `register_tb` ON `rental_booking_tb`.`user_id` = `register_tb`.`log_id` WHERE `rental_booking_tb`.`user_id` = '$user_id' AND `rental_booking_tb`.`status` = '$req_status';");
$list=array();

if($data->num_rows>0){
    while($row=mysqli_fetch_assoc($data)){
       // $list[]=$row;

       $myarray['rent_book_id']=$row['rent_book_id'];
       $myarray['pro_phone']=$row['pro_phone'];
       $myarray['days']=$row['days'];
       $myarray['pick_up_date']=$row['pick_up_date'];
       $myarray['pick_up_time']=$row['pick_up_time'];
       $myarray['pay']=$row['pay'];
       $myarray['rent']=$row['rent'];
       $myarray['fuel']=$row['fuel'];
       $myarray['type']=$row['type'];
       $myarray['rental_id']=$row['rental_id'];
       $myarray['image']=$row['image'];
       $myarray['username']=$row['username'];
       $myarray['phone']=$row['phone'];
              $myarray['pay_status']=$row['pay_status'];
       $myarray['veh_receive_status']=$row['veh_receive_status'];
       $myarray['advance_amt']=$row['advance_amt'];


       $myarray['result']="success";
       array_push($list,$myarray);
    }   

} 
else{
    $myarray['result']="failed";
    array_push($list,$myarray);
   // $list='Failed';
 
}
echo json_encode($list);
?>
