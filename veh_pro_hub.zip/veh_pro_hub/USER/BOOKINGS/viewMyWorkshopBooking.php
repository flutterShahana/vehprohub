<?php
include '../../connect.php';
$user_id=$_POST['user_id'];
$req_status=$_POST['req_status'];

$data=mysqli_query($conn,"SELECT * FROM workshop_booking_tb INNER JOIN workshop_tb ON `workshop_booking_tb`.`work_id` = `workshop_tb`.`work_id` INNER JOIN ( SELECT `register_tb`.`phone` as pro_phone, `workshop_tb`.`work_id` FROM `workshop_tb` INNER JOIN `register_tb` ON `workshop_tb`.`pro_id` = `register_tb`.`log_id` ) AS `subquery` ON `workshop_tb`.`work_id` = `subquery`.work_id INNER JOIN `register_tb` ON `workshop_booking_tb`.`user_id` = `register_tb`.`log_id` WHERE `workshop_booking_tb`.`user_id` = '$user_id' AND `workshop_booking_tb`.`status` = '$req_status';
");

$list=array();

if($data->num_rows>0){
    while($row=mysqli_fetch_assoc($data)){
       // $list[]=$row;

       $myarray['work_book_id']=$row['work_book_id'];
       $myarray['work_id']=$row['work_id'];
       $myarray['pro_phone']=$row['pro_phone'];
       $myarray['amount']=$row['amount'];
       $myarray['serviceName']=$row['serviceName'];
       $myarray['booking_date']=$row['booking_date'];
       $myarray['booking_time']=$row['booking_time'];
       $myarray['avgTime']=$row['avgTime'];
       $myarray['type']=$row['type'];
       $myarray['username']=$row['username'];
       $myarray['result']="success";
       $myarray['phone']=$row['phone'];
       $myarray['pay_status']=$row['pay_status'];
       $myarray['service_completion']=$row['service_completion'];
       $myarray['advance_amt']=$row['advance_amt'];

       array_push($list,$myarray);
    }   

} 
else{
    $myarray['result']="failed";
    array_push($list,$myarray);
   // $list='Failed';
 
}
echo json_encode($list);
?>
