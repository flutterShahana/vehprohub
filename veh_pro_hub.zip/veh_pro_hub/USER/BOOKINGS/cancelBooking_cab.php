<?php
include '../../connect.php';
$booking_id=$_POST['booking_id'];



$sql1=mysqli_query($conn,"UPDATE  booking_tb set status='cancelled'  where book_id='$booking_id'");
if($sql1){
    $myarray['result']="success";
    $myarray['response']="done";
} else{
    $myarray['result']="failed";
   
}
echo json_encode($myarray);
?>