
<?php
include '../connect.php';
$type=$_POST['vehType'];
$service=$_POST['service'];


$data=mysqli_query($conn,"SELECT * FROM workshop_tb inner JOIN register_tb on workshop_tb.pro_id=register_tb.log_id WHERE workshop_tb.type='$type' && serviceName='$service'
");

$list=array();

if($data->num_rows>0){
    while($row=mysqli_fetch_assoc($data)){
       // $list[]=$row;

       $myarray['work_id']=$row['work_id'];
       $myarray['serviceName']=$row['serviceName'];
       $myarray['amount']=$row['amount'];
       $myarray['avgTime']=$row['avgTime'];
       $myarray['username']=$row['username'];
       $myarray['phone']=$row['phone'];
       $myarray['lati']=$row['lati'];
       $myarray['longi']=$row['longi'];
       $myarray['location']=$row['location'];
       $myarray['log_id']=$row['log_id'];
       $myarray['result']="success";
       array_push($list,$myarray);
    }   

} 
else{
    $myarray['result']="failed";
    array_push($list,$myarray);
   // $list='Failed';
 
}
echo json_encode($list);
?>
