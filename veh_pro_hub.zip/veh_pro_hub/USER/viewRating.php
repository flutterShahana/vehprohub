


<?php
include '../connect.php';
$service=$_POST['service'];


$data=mysqli_query($conn,"SELECT * FROM feedback_tb INNER JOIN register_tb on feedback_tb.user_id=register_tb.log_id where feedback_tb.service='$service'
");

$list=array();

if($data->num_rows>0){
    while($row=mysqli_fetch_assoc($data)){
       // $list[]=$row;

       $myarray['username']=$row['username'];
       $myarray['date']=$row['date'];
       $myarray['feedback']=$row['feedback'];
       $myarray['star']=$row['star'];
       $myarray['user_id']=$row['user_id'];
       $myarray['result']="success";
       array_push($list,$myarray);
    }   

} 
else{
    $myarray['result']="failed";
    array_push($list,$myarray);
   // $list='Failed';
 
}
echo json_encode($list);
?>
