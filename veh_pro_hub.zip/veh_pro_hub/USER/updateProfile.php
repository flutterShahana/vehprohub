<?php
include '../connect.php';
$name=$_POST['name'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$pass=$_POST['password'];
$user_id=$_POST['user_id'];
$sql1= mysqli_query($conn,"UPDATE  login_tb set email= '$email',password='$pass' where log_id='$user_id'");
$sql2=mysqli_query($conn,"UPDATE  register_tb set username='$name',phone='$phone'where log_id='$user_id'");
if($sql1 && $sql2){
    $myarray['result']="success";
    $myarray['response']="done";
} else{
    $myarray['result']="failed";
   
}
echo json_encode($myarray);
?>