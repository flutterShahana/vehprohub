<?php
include '../connect.php';
$description=$_POST['description'];
$user_id=$_POST['user_id'];

$img=$_FILES['image']['name'];                  //img--->php;    image---->from flutter...use this in postman
$imagepath='../dp/'.$img;
$tmp_name=$_FILES['image']['tmp_name'];
move_uploaded_file($tmp_name,$imagepath);


$sql1=mysqli_query($conn,"UPDATE  register_tb set profile_image='$img' where log_id='$user_id'");
if($sql1){
    $myarray['result']="success";
    $myarray['response']="done";
} else{
    $myarray['result']="failed";
   
}
echo json_encode($myarray);
?>