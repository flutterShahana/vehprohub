
<?php
include '../connect.php';
$user_id=$_POST['user_id'];



$data=mysqli_query($conn,"SELECT * FROM register_tb inner JOIN login_tb on register_tb.log_id=login_tb.log_id WHERE register_tb.log_id='$user_id' ;");

$list=array();

if($data->num_rows>0){
    while($row=mysqli_fetch_assoc($data)){
       // $list[]=$row;

       $myarray['reg_id']=$row['reg_id'];
       $myarray['username']=$row['username'];
       $myarray['phone']=$row['phone']; 
       $myarray['place']=$row['place'];
       $myarray['lati']=$row['lati'];
       $myarray['longi']=$row['longi'];
       $myarray['location']=$row['location'];
       $myarray['log_id']=$row['log_id'];
       $myarray['email']=$row['email'];
       $myarray['password']=$row['password'];
       $myarray['type']=$row['type'];
       $myarray['image']=$row['profile_image'];
       $myarray['result']="success";
       array_push($list,$myarray);
    }   

} 
else{
    $myarray['result']="failed";
    array_push($list,$myarray);
   // $list='Failed';
 
}
echo json_encode($list);
?>
