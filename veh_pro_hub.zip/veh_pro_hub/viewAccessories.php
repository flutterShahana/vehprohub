
<?php
include 'connect.php';
$pro_id=$_POST['pro_id'];
$type=$_POST['type'];


$data=mysqli_query($conn,"SELECT * FROM accessories_tb inner JOIN register_tb on accessories_tb.pro_id=register_tb.log_id WHERE accessories_tb.pro_id='$pro_id'  && accessories_tb.quantity>0 && accessories_tb.type='$type'");

$list=array();

if($data->num_rows>0){
    while($row=mysqli_fetch_assoc($data)){
       // $list[]=$row;

       $myarray['description']=$row['des'];
       $myarray['image']=$row['image'];
       $myarray['type']=$row['type'];
       $myarray['name']=$row['name'];
       $myarray['brand']=$row['brand'];
       $myarray['rate']=$row['rate'];
       $myarray['phone']=$row['phone'];
       $myarray['quantity']=$row['quantity'];
       $myarray['log_id']=$row['log_id'];
       $myarray['acc_id']=$row['acc_id'];
       $myarray['result']="success";
       array_push($list,$myarray);
    }   

} 
else{
    $myarray['result']="failed";
    array_push($list,$myarray);
   // $list='Failed';
 
}
echo json_encode($list);
?>
