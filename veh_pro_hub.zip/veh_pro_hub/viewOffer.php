<?php
include 'connect.php';
$pro_id=$_POST['pro_id'];

$sql1=mysqli_query($conn,"SELECT * FROM offer_tb where pro_id='$pro_id' order by offer_id desc");
$list=array();

if($sql1->num_rows>0){
    while($row=mysqli_fetch_assoc($sql1)){
    $myarray['result']="success";

    $myarray['offer']=$row['offer'];
    $myarray['start_date']=$row['start_date'];
    $myarray['end_date']=$row['end_date'];
    $myarray['offer_id']=$row['offer_id'];
    array_push($list,$myarray);

    }
} else{
    $myarray['result']="failed";
    array_push($list,$myarray);

   
}
echo json_encode($list);
?>