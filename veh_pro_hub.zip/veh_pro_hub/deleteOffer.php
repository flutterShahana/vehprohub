<?php
include 'connect.php';
$offer_id=$_POST['offer_id'];

$sql1=mysqli_query($conn,"DELETE FROM offer_tb where offer_id='$offer_id'");

if($sql1){
    $myarray['result']="success";
    $myarray['response']="done";
} else{
    $myarray['result']="failed";
   
}
echo json_encode($myarray);
?>