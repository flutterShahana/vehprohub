<?php 

    include'connect.php';
	$acc_id = $_POST['acc_id'];
	
	$sql = $conn->query("DELETE from accessories_tb where acc_id='$acc_id'");
if($sql){
	
		$myarray['result']="success";
       
	}


else 

{
	$myarray['result']="failed";

	

}
	echo json_encode($myarray);
    ?>