<?php
include 'connect.php';
$uname=$_POST['uname'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$pass=$_POST['pass'];
$type=$_POST['type'];
$sql1= mysqli_query($conn,"INSERT INTO login_tb(email,password,type)values('$email','$pass','$type')");
$user_id=mysqli_insert_id($conn);
$sql2=mysqli_query($conn,"INSERT INTO register_tb(username,phone,log_id)values('$uname','$phone','$user_id')");
if($sql1 && $sql2){
    $myarray['result']="success";
    $myarray['response']="done";
} else{
    $myarray['result']="failed";
   
}
echo json_encode($myarray);
?>