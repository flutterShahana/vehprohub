<?php 

    include'connect.php';
	$rent_id = $_POST['rent_id'];
	
	$sql = $conn->query("DELETE from rentals_tb where rent_id='$rent_id'");
if($sql){
	
		$myarray['result']="success";
       
	}


else 

{
	$myarray['result']="failed";

	

}
	echo json_encode($myarray);
    ?>