<?php 

    include'connect.php';
	$acc_id = $_POST['acc_id'];
	$rate = $_POST['rate'];
	
	$sql = $conn->query("UPDATE accessories_tb set rate='$rate'where acc_id='$acc_id'");
if($sql){
	
		$myarray['result']="success";
       
	}


else 

{
	$myarray['result']="failed";

	

}
	echo json_encode($myarray);
    ?>