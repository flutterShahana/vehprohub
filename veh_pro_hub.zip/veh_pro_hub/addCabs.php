<?php
include 'connect.php';
$description=$_POST['description'];
$name=$_POST['name'];
$rate=$_POST['rate'];
$person=$_POST['person'];
$type=$_POST['type'];
$pro_id=$_POST['pro_id'];
$size=$_POST['size'];

$img=$_FILES['image']['name'];                  //img--->php;    image---->from flutter...use this in postman
$imagepath='cabs/'.$img;
$tmp_name=$_FILES['image']['tmp_name'];
move_uploaded_file($tmp_name,$imagepath);


$sql1=mysqli_query($conn,"INSERT INTO cabs_tb(size,des,name,person,pro_id,rate,image,type)values('$size','$description','$name','$person','$pro_id','$rate','$img','$type')");
if($sql1){
    $myarray['result']="success";
    $myarray['response']="done";
} else{
    $myarray['result']="failed";
   
}
echo json_encode($myarray);
?>