<?php 

    include'connect.php';
	$cab_id = $_POST['cab_id'];
	$rate = $_POST['rate'];
	
	$sql = $conn->query("UPDATE cabs_tb set rate='$rate'where cab_id='$cab_id'");
if($sql){
	
		$myarray['result']="success";
       
	}


else 

{
	$myarray['result']="failed";

	

}
	echo json_encode($myarray);
    ?>