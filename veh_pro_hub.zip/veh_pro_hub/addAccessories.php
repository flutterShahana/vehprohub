<?php
include 'connect.php';
$name=$_POST['name'];
$rate=$_POST['rate'];
$description=$_POST['description'];
$brand=$_POST['brand'];
$type=$_POST['type'];
$quantity=$_POST['quantity'];
$pro_id=$_POST['pro_id'];

$img=$_FILES['image']['name'];                  //img--->php;    image---->from flutter...use this in postman
$imagepath='accessories/'.$img;
$tmp_name=$_FILES['image']['tmp_name'];

move_uploaded_file($tmp_name,$imagepath);
$sql1=mysqli_query($conn,"INSERT INTO accessories_tb(des,brand,name,pro_id,quantity,rate,type,image)values('$description','$brand','$name','$pro_id','$quantity','$rate','$type','$img')");
if($sql1){
    $myarray['result']="success";
    $myarray['response']="done";
} else{
    $myarray['result']="failed";
   
}
echo json_encode($myarray);
?>