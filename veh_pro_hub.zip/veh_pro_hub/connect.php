<?php
$conn=new mysqli('localhost','root','','auto_pro_hub');
// if($conn){
//     echo "success";
// }
// else{
//     echo "fail";
// }
?>

