<?php
include 'connect.php';
$type=$_POST['type'];
$name=$_POST['name'];
$description=$_POST['description'];
$rent=$_POST['rent'];
$fuel=$_POST['fuel'];
$pro_id=$_POST['pro_id'];

$img=$_FILES['image']['name'];                  
$imagepath='rentals/'.$img;
$tmp_name=$_FILES['image']['tmp_name'];
move_uploaded_file($tmp_name,$imagepath);


$sql1=mysqli_query($conn,"INSERT INTO rentals_tb(type,name,des,rent,fuel,image,pro_id)values('$type','$name','$description','$rent','$fuel','$img','$pro_id')");
if($sql1){
    $myarray['result']="success";
    $myarray['response']="done";
} else{
    $myarray['result']="failed";
   
}
echo json_encode($myarray);
?>