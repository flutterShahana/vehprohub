


<?php
include 'connect.php';
$pro_id=$_POST['pro_id'];
$req_status=$_POST['req_status'];

$data=mysqli_query($conn,"SELECT acc_booking_tb.*,accessories_tb.*,register_tb.*,acc_booking_tb.quantity as book_qnty FROM `acc_booking_tb` INNER JOIN `accessories_tb` ON `acc_booking_tb`.`acc_id` = `accessories_tb`.`acc_id` INNER JOIN `register_tb` ON `acc_booking_tb`.`user_id` = `register_tb`.`log_id` WHERE accessories_tb.pro_id='$pro_id' AND `acc_booking_tb`.`status` = '$req_status';
");


$list=array();

if($data->num_rows>0){
    while($row=mysqli_fetch_assoc($data)){
    //    $list[]=$row;

       $myarray['acc_book_id']=$row['acc_book_id'];
       $myarray['acc_id']=$row['acc_id'];
       $myarray['quantity']=$row['book_qnty'];
       $myarray['rate']=$row['rate'];
       $myarray['name']=$row['name'];
       $myarray['brand']=$row['brand'];
       $myarray['type']=$row['type'];
       $myarray['image']=$row['image'];
       $myarray['username']=$row['username'];
       $myarray['result']="success";
       $myarray['phone']=$row['phone'];
       $myarray['pay_status']=$row['pay_status'];

       array_push($list,$myarray);
    }   

} 
else{
    $myarray['result']="failed";
    array_push($list,$myarray);
   // $list='Failed';
 
}
echo json_encode($list);
?>
