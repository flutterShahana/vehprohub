<?php 

    include'connect.php';
	$work_id = $_POST['work_id'];
	
	$sql = $conn->query("DELETE from workshop_tb where work_id='$work_id'");
if($sql){
	
		$myarray['result']="success";
       
	}


else 

{
	$myarray['result']="failed";

	

}
	echo json_encode($myarray);
    ?>