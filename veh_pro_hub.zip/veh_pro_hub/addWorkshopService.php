<?php
include 'connect.php';

$pro_id=$_POST['pro_id'];
$service=$_POST['service'];
$amt=$_POST['amt'];
$timeTaken=$_POST['timeTaken'];
$type=$_POST['type'];




$sql1=mysqli_query($conn,"INSERT INTO workshop_tb(pro_id,serviceName,amount,avgTime,type)values('$pro_id','$service','$amt','$timeTaken','$type')");
if($sql1){
    $myarray['result']="success";
    $myarray['response']="done";
} else{
    $myarray['result']="failed";
   
}
echo json_encode($myarray);
?>