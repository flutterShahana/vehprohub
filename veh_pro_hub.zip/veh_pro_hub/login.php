<?php
include 'connect.php';
  $email=$_POST['email'];
  $password=$_POST['pass'];
  $type=$_POST['type'];
 $sql= mysqli_query($conn,"SELECT * from login_tb  where email='$email'&& password='$password'&& type='$type'");
  if($sql->num_rows>0){

    while($row=mysqli_fetch_assoc($sql)){
      
        $myarray['message']='User Successfully Logged In';
         $myarray['login_id']=$row['log_id'];
        //  $myarray['lati']=$row['lati'];
        //  $myarray['longi']=$row['longi'];
        //  $myarray['location']=$row['location'];
        //  $myarray['place']=$row['place'];
    }
  }
  else{
    $myarray['message']='Failed to Login';
  }
echo json_encode($myarray);
?>