<?php
include 'connect.php';
$pro_id=$_POST['pro_id'];
$start=$_POST['start'];
$end=$_POST['end'];

$img=$_FILES['image']['name'];                  
$imagepath='offer/'.$img;
$tmp_name=$_FILES['image']['tmp_name'];
move_uploaded_file($tmp_name,$imagepath);


$sql1=mysqli_query($conn,"INSERT INTO offer_tb(pro_id,offer,start_date,end_date)values
('$pro_id','$img','$start','$end')");
if($sql1){
    $myarray['result']="success";
    $myarray['response']="done";
} else{
    $myarray['result']="failed";
   
}
echo json_encode($myarray);
?>