<?php
include 'connect.php';
//$office_id=$_POST['officeId'];
$booikingId=$_POST['booikingId'];
$hr=$_POST['hr'];
$sql1= mysqli_query($conn,"UPDATE booking_tb set tot_hr='$hr'where book_id='$booikingId'");
if($sql1){
    $myarray['result']="success";
    $myarray['response']="done";
} else{
    $myarray['result']="failed";
   
}
echo json_encode($myarray);
?>