<?php
include 'connect.php';
$uid=$_GET['id'];
$approveStatus=$_GET['status'];
$type=$_GET['userType'];
$sql = mysqli_query($con, "UPDATE login_tb set approval_status='$approveStatus' where log_id='$uid'");
if ($sql) {
    // echo "Request ".$approveStatus;
    echo"<script>alert('Request $approveStatus');</script>";
    // echo "<script>alert('Request " . htmlspecialchars($approveStatus, ENT_QUOTES) . "');</script>";

    if($type=='user'){
        echo "<script>window.location.href='aph_approval_user.php'; </script>";

    }else{
        echo "<script>window.location.href='aph_approval_serviceprovider.php'; </script>";

    }
} else {
    
    // echo "Fail to update !!";
    echo"<script>alert('Failed to  Update !');</script>";
    if($type=='user'){
        echo "<script>window.location.href='aph_approval_user.php'; </script>";

    }else{
        echo "<script>window.location.href='aph_approval_serviceprovider.php'; </script>";

    }
  //  header("location:vet.php");
}
?>
