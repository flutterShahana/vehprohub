<?php 
$con= new mysqli('localhost','root','','auto_pro_hub');
// if($con->connect_error){
//     die("Connection Failed".$con->connect_error);
//  }else
//  {
//     echo "success";
//  }

?>